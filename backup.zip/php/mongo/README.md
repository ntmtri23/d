* Source: `git clone https://github.com/mongodb/mongo-php-driver.git`
* Github: https://github.com/mongodb/mongo-php-driver
